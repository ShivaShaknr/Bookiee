import './log.css';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Redirect,
  } from "react-router-dom";
import React, { Component } from 'react'
export default class App extends Component {
    render() {
        return (
          <body>
          <button>new user then register</button>
          </body>
        )
      }
}